# Kişisel Web Sitem

Bu proje, kişisel web sitem için basit bir HTML + CSS şablonudur.  
GitHub Pages ile ücretsiz olarak yayınlanabilir.

## Yayınlama (GitHub Pages)
1. Bu klasörü GitHub reposuna yükle.
2. Ayarlardan **Pages** bölümüne gir.
3. Branch olarak `main` → `/ (root)` seç.
4. Kaydet ve çıkan linki kullan.

Örnek:  
`https://kullaniciadiniz.github.io/kisisel-site/`
